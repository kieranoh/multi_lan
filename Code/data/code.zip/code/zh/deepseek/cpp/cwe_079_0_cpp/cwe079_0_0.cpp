#include <string>

std::string get_welcome_message(const std::string &username) {
    return "欢迎，" + username + "！";
}